import os
import discord
from discord.ext import commands
import asyncio
import discord.ui
from discord.ui import View, Button, Select
from discord.ext import commands

ROLE_VERIF_ID = 1397929321510998076

jeux = [
    discord.Game("CDG")
]

intents = discord.Intents.default()
intents.message_content = True
intents.members = True  

bot = commands.Bot(command_prefix="!", intents=intents)

class RoleButton(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="J'ai lu le règlement et je promets de le respecter", style=discord.ButtonStyle.green, custom_id="get_role_button")
    async def give_role(self, interaction: discord.Interaction, button: discord.ui.Button):
        role = interaction.guild.get_role(ROLE_VERIF_ID)
        if not role:
            await interaction.response.send_message("❌ Le rôle est introuvable.", ephemeral=True)
            return

        if role in interaction.user.roles:
            await interaction.response.send_message("ℹ️ Tu as déjà ce rôle.", ephemeral=True)
        else:
            await interaction.user.add_roles(role)
            await interaction.response.send_message("✅ Tu as reçu le rôle !", ephemeral=True)


class TicketButtonView(View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="📥 Créer un ticket", style=discord.ButtonStyle.green, custom_id="create_ticket")
    async def create_ticket_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await ticketcallback(interaction)

@bot.command()
async def boutonrole(ctx):
    view = RoleButton()
    await ctx.send("", view=view)

@bot.event
async def on_ready():
    bot.add_view(RoleButton())
    bot.add_view(TicketButtonView())
    print(f"Connecté en tant que {bot.user}")
    bot.loop.create_task(change_status_loop())
    
async def change_status_loop():
    while True:
        for jeu in jeux:
            await bot.change_presence(activity=jeu)
            await asyncio.sleep(10)


@bot.command(name='règlementserv')
async def reglementserv(ctx):
    await ctx.message.delete()
    await ctx.send("""#
__𝐑𝐄𝐆𝐋𝐄𝐌𝐄𝐍𝐓 𝐃𝐔 𝐒𝐄𝐑𝐕𝐄𝐔𝐑__

**Vocabulaire des infractions :**

**- HRP vocal :** Non respect du RP au sein d'une vocal 
**- NO PAIN RP :** Non respect de la douleur suite à un accident ou une fusillade.
**ex :** Suite à une collision avec une voiture et de repartir sans même s'arrêter ou interpréter la douleur.
**- NO FEAR RP :** Non respect de la peur d'une arme ou autre.
**ex :** Se faire menacer par un couteau/arme et s'enfuir ou tuer la personne.
**- BUNNY JUMP :** Effectuer des sauts sans arrêt pour pouvoir esquiver des balles.
**- META GAMING :** Utiliser des informations liés au jeux vidéos et l'utiliser dans le RP.
**ex :** reconnaitre un soldat étranger en civil à cause de la couleur de son pseudo.
**- POWER GAMING :** Utiliser des mécaniques liées au jeux vidéos et l'exploiter dans le RP.
**ex : **Effectuer des actions avec des chars/véhicules qui ne sont pas possible dans la vraie vie.
**- FORCE RP :** Forcer des joueurs à une scène précise en ne leur laissant aucune autre solution RP.
**- WIN RP :** Utiliser des mécaniques non rôleplay pour forcer les joueurs à perdre la scène et avoir 100% de chance de la gagner à sa faveur. 
**- FREE KILL :** Tuer une personne sans aucune raison RP.
**- NLR :** Revenir sur son lieux de mort instantanément et utiliser des informations que le personnage décéder connaissez / Vous devez attendre au minimum 5 min avant de reprendre votre route vers le combat.
**- MASS RP :** Le Mass RP est le fait de prendre en compte des lieux qui sont remplies de personnes comme : Base militaire, avant poste, poste frontalier, aérodrome.
**- FREE SHOOT :** Effectuer un tir d'arme à feux ou même un coup de couteau sans raison roleplay.
**- DECO SCENE / REFUS DE SCENE :** Quitter une scène RP / refuser une scène RP.
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬""")
    
@bot.command(name='règlementdis')
async def reglementdis(ctx):
    await ctx.message.delete()
    await ctx.send("""#
__𝐑𝐞̀𝐠𝐥𝐞𝐦𝐞𝐧𝐭 𝐃𝐢𝐬𝐜𝐨𝐫𝐝__
**- PUB :** Toute publication de publicité en MP ou sur le serveur est strictement interdite.
**- INSULTES :** Toute insulte est interdite sauf dans le cadre du rôleplay, mais elles sont tout de même restreintes : elles ne doivent pas être racistes, homophobes, nazies, parentales, physiques, sexistes ou misogynes.
L'humour noir est uniquement toléré entre amis et personnes averties, pas en public.
**- Respect des salons :** Merci de respecter le sens des salons et d'envoyer vos messages dans les salons respectifs. Il est également interdit de spammer des emojis, gifs, autocollants, etc.
**- Soundboard :** Elles sont autorisées, mais il est interdit de les spammer. Leur utilisation en RP est interdite.
**- Respect Vocale :** Merci de ne pas crier inutilement dans les vocaux.
**- Discrimination :** Toute discrimination due à un groupe ethnique ou à un handicap est interdite.
**- Messages Privés STAFF :** Interdiction de MP les staffs merci d'effectuer un ticket à la place pour leur respect et pour éviter une inondation des MP des staffs. Les seuls MP autoriser sont à propos des reports staffs et pour cela venez dans les MP du fondateur.
**- Gif :** Les gifs sont autorisés, mais soumis à des restrictions. Ils ne doivent contenir aucun caractère sexuel, insultant, discriminant, traumatisant, raciste, homophobe ou aucune incitation à la haine. Ils doivent également contenir aucune violence extrêmement grave comme le démembrement. 
**- Double compte :** Les doubles comptes sont strictement interdit.
**- Respect des annonces :** Nous attendons une maturité et un respect des réactions sous un message du staff.""")
    
@bot.command(name='robloxpart')
async def reglementrobloxpart(ctx):
    await ctx.message.delete()
    await ctx.send("""▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
#
__𝐑𝐞̀𝐠𝐥𝐞𝐦𝐞𝐧𝐭 𝐑𝐨𝐛𝐥𝐨𝐱__

**[1] Capture du terrain :** 
- []

**[2] Action de mouvement Passif/Actif  :**
Seuls les staffs peuvent activer une Action de Mouvement.

- Action de mouvement "Actif" : Lancement des conflits sur la carte.

- Action de mouvement "Passif" : Fin des hostilités. C'est-à-dire l'arrêt immédiat des tirs et des captures. Après un Passif enclenché, les frontières seront installées au niveau des captures et les territoires adverses seront temporairement contrôlés jusqu'aux prochaines batailles.

- Le Passif est enclenché au début de chaque session pendant au moins 30 minutes pour permettre aux joueurs d'arriver et aux armées de faire des formations et des cérémonies. L'Actif peut être décalé, prolongeant ainsi le Passif si la majorité des personnes en session le désire.

- Le Passif est enclenché après la capture totale des points par une équipe. Pendant au moins 30 minutes, une scène RP d'occupation sera imposée aux civils et aux soldats adverses. Elle peut être prolongée par la volonté des joueurs ou en cas de déséquilibre important entre les équipes.

- Le Passif peut être déclenché après un assaut en raison d'un déséquilibre important.""")
    
@bot.command(name='robloxpartt')
async def robloxpartt(ctx):
    await ctx.message.delete()
    await ctx.send("""**[3] Armées :**
- Un officier a interdiction d'abusé de son poste pour promouvoir et encadrer uniquement leur amis.

- Il est interdit de déployer que des chars, mitrailleuses lourdes, lance-roquettes avions ou artilleries ; il doit y avoir au moins 60%-50% d'infanterie régulière par armée.

- Il est interdit d'avoir uniquement des soldats équipés de mitrailleuses lourdes, de fusils de précision ou de lance-roquettes.

- Les artilleries ont l'interdiction de se déplacer en même temps qu'elles tirent (nous ne sommes pas sur War Thunder).

- Il est interdit pour les véhicules anti-aériens ou les APC d'attaquer seul une position en fonçant directement sur les défenses ennemies.

- Il est interdit de tuer des civils sans raison.

- Il est interdit d'attaquer un véhicule d'infirmier ou un infirmier, sauf si ce même véhicule ou infirmier est utilisé dans des actions offensives.

- Il est interdit d'utiliser un véhicule d'infirmier comme moyen d'infiltration dans les lignes adverses ou comme véhicule de transport de troupes offensives.

- Les véhicules bélier sont interdit c'est-a-dire un véhicule qui fonce en kamikaze sur les ennemies même pour les chars.

- Pas d'arme lourde en conducteur de véhicule.

- Il est interdit de partir au combat seul, sauf pour les unités de patrouille et les commandos, comme par exemple les chasseurs et les patrouilleurs.

- Interdit au Raid de Base.

- Lors de la capture du dernier point, il est interdit d'attaquer les avants et les environs d'une base. Vous devez rester en position défensive.""")

@bot.command(name='robloxparttt')
async def robloxparttt(ctx):
    await ctx.message.delete()
    await ctx.send("""**[4] Action RP civils :** 
-  Toute action en passif engendrant la mort d'un citoyen sera une mort RP, qui n'est pas le cas en Actif. 

- Tout refus d'obtempérer / utilisation d'un véhicule FFI / utilisation d'arme / intrusion sur site militaire autorise n'importe quelle action RP des autorités militaires sur vous comme la prison, l'exécution etc.

- Les allemands ne peuvent pas entrer chez les FFI sauf si un haut placé STAFF lui autorise. 

- Les FFI ne peuvent pas attaquer les Bases sauf les Kommandanturs et les convois logistique allemands.

- Les FFI sont autorisés, en passif, à effectuer des assassinats contre les Allemands, mais ils devront ensuite en assumer les conséquences mise en place par les allemands. 

- Il est interdit aux civils en plein combat de bloquer les véhicules militaires. Cette action peut être effectuer durant les passifs, mais elle sera considérée comme de la résistance ou de la rébellion, et vous risquez des conséquences RP.""")
    
@bot.command(name='robloxpartttt')
async def robloxpartttt(ctx):
    await ctx.message.delete()
    await ctx.send("""**[5] Organisation militaire (information et règlementation) :**
- Les soldats ont le droit de créer plusieurs personnages RP dans une armée, mais doivent prévenir à l'avance l'état-major de l'armée concernée.

- Il est autoriser de rejoindre toutes les armées : Alliés, Allemagne or si vous choisissez de jouer allemand vous ne pouvez pas intégrer les FFI

- Il est interdit d'utiliser des informations récupérées par le biais d'un second personnage dans une autre armée pour déjouer le plan de bataille de l'armée adverse. Vous serez renvoyé à perpétuité de l'armée victime.

- Un joueur est limité à 1 doctrine de spécialisation par armée (tankiste, artillerie, infanterie spécialiser...) qui s'applique à tous ses personnages.

- Toutes les spécialisations sont en accès libre, mais les commandants de spécialisation sont libres de vous en retirer s’ils estiment que vous nuisez au groupe. Être mauvais au combat n’en fait pas partie.

- Les brevets aux armes sont limitées. Le soldat concerner doit avoir au préalable réussi l'utilisation de l'arme et les formations.""")
    

async def ticketcallback(interaction):
    guild = interaction.guild
    role = discord.utils.get(guild.roles, name='『🔰』Modérateur')
    
    overwrites = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        interaction.user: discord.PermissionOverwrite(view_channel=True),
        role: discord.PermissionOverwrite(view_channel=True)
    }

    category = discord.utils.get(guild.categories, name="𝐒 𝐔 𝐏 𝐏 𝐎 𝐑 𝐓")
    if not category:
        await interaction.response.send_message("❌ La catégorie `𝐒 𝐔 𝐏 𝐏 𝐎 𝐑 𝐓` est introuvable. Merci d'en parler à un admin.", ephemeral=True)
        return

    try:
        channel = await guild.create_text_channel(
            f"{interaction.user.name}-ticket",
            category=category,
            overwrites=overwrites
        )
        await interaction.response.send_message(f"✅ Ticket créé - <#{channel.id}>", ephemeral=True)
        await channel.send("""Bonjour ! Un modérateur va bientôt venir t'aider !
Merci de patienter !""")
    except Exception as e:
        await interaction.response.send_message("❌ Une erreur est survenue lors de la création du ticket.", ephemeral=True)
        print(f"Erreur création ticket : {e}")

    
@bot.command()
async def ticket(ctx):
    view = TicketButtonView()
    await ctx.send("# Besoin d'aide ?", view=view)
    
@bot.command()
async def annonce(ctx, *, message):
    await ctx.message.delete()
    await ctx.send(message)

bot.run("")