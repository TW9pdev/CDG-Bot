---Bot créé pat TW9p---



**Liste des commandes:**



*-Pour le règlement:*



Etant donné que le règlement est trop long pour un seul message, j'ai fais plusieurs commandes pour l'afficher, donc si vous le supprimez puis vous le remettez, il faut faire c'est commandes dans l'ordre:

1-!règlementserv

2-!règlementdis

3-!robloxpart

4-!robloxpartt

5-!robloxparttt

6-!robloxpartttt



*(oui j'avais pas d'inspi)*



*-Pour faire une annonce:*



Il faut faire !annonce *votre\_annonce\_ici* et le message sera envoyé par le bot.



Exemple: Vous: !annonce Bonjour tout le monde !

Bot: Bonjour tout le monde



*(Les \*\* pour mettre en gras, les pings et les # des channels marchent)*



*-Pour les tickets:*



Tout marche donc pas besoin de toucher mais si sans faire exprès vous supprimez le bouton, il vous suffit de faire !ticket pour en faire apparaître un nouveau.









